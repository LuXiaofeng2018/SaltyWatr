%--------------------Copyright Statement------------------------%
%   Saltywatr V.1.0.0, a collection of Matlab functions which 
%   simulate shallow-water, variable denisty flow.
%   Copyright (c) 2002, Brice G. Loose

%   This " Original Work " is free; you can modify it under 
%   the terms of the AFL Academic Free License. This "Original 
%   Work" is distributed in the hope that it will be useful, but 
%   WITHOUT ANY WARRANTY; without even the implied warranty of 
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See 
%   the AFL Academic Free License  for more details. You should 
%   find a copy of the AFL Academic Free License in the highest 
%   level directory of this distribution; if not, you may obtain
%   one at the Open Source Initiative, http://www.opensource.org.  
%--------------------------------Description---------------------%
%
%   Program example1.m is an example program for the flow model Saltywatr.  You need Matlab to run
%   this routine.  example1.m is a simulation of a partial dam failure.  A 200x200 m square box is full
%   of water; 10 m on one side of the dam and 5 m on the other.  At time t=0 a 70 m section of the 
%   dam fails or "disappears" leaving a discontinuity in the water depth.
%
%-------------------------Brice Loose, Cristian Escauriaza WRC, 2002 -----------------------%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%   Establish the input parameters:

flow = 0; fric = 0;
filein = 'damquad';
fileout = 'temp';
tot = 10;


%   Fix path to find the location of the routines
sendero = eval(['pwd']);
addpath(sendero,[sendero(1:end-8),'bin\']);

%   Execute Saltywatr
disp(' Running the simulation... ');
Saltywatr(filein,fileout,fric,flow,tot);

%   Plot
display('Plotting..');
eval(['load ',fileout]);

for j = 1:dimm-1,
    plotdam(hight(:,j),xc,yc,200,5);
end
