function P = plotdam(va,x,y,L,dx);

%--------------------Copyright Statement------------------------%
%   Saltywatr V.1.0.0, a collection of Matlab functions which 
%   simulate shallow-water, variable denisty flow.
%   Copyright (c) 2002, Brice G. Loose

%   This " Original Work " is free; you can modify it under 
%   the terms of the AFL Academic Free License. This "Original 
%   Work" is distributed in the hope that it will be useful, but 
%   WITHOUT ANY WARRANTY; without even the implied warranty of 
%   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See 
%   the AFL Academic Free License  for more details. You should 
%   find a copy of the AFL Academic Free License in the highest 
%   level directory of this distribution; if not, you may obtain
%   one at the Open Source Initiative, http://www.opensource.org.  
%--------------------------------Description---------------------%
% A routine to plot the output from the dambreak problem.
%
%-------------------------Brice Loose, Cristian Escauriaza WRC, 2002 -----------------------%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



    n = L/dx;
    load damquad2;
    H(stay)=va;
    H(elim1)=nan;
    H(elim2)=nan;

    P=reshape(H,n,n);


   hand = mesh(P);
    colormap([0.1 .9 .9]); 
    shading('faceted');
    %light('Position',[1 1 0],'Style','infinite');
    set(gca,'zlim',[5 10]); %set(gca,'xdir','rev');
    view(121,18);
    set(gca,'xtick',[0 40]); set(gca,'ytick',[0 40]);
    set(gca,'xticklabel',[0 200]); set(gca,'yticklabel',[0 200]);
    zlabel('depth (m)');
    pause(1);
return


